<!DOCTYPE html>
<html>
	<head>
		<meta name="viewport"  content="width=device-width, initial-scale=1, user-scalable=no">
		<meta name="description" content="">
		<meta property="og:url" content="" />
		<meta property="og:type" content="website" />
		<meta property="og:title" content="" />
		<meta property="og:description" content="" />
		<meta property="og:image" content="" />
		<link type="text/css" rel="stylesheet" href="assets/css/style.css"/>
		<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
		<link rel="stylesheet" href="plugins/jqueryupload/dist/css/dropify.min.css">
		
		<link type="text/css" rel="stylesheet" href="assets/css/normalize.css"/>
		<link type="text/css" rel="stylesheet" href="assets/css/ionicons.css"/>
		<link rel="shortcut icon" href="assets/img/logo.png" type="image/x-icon">
		<link rel="icon" href="assets/img/logo.png" type="image/x-icon">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
		<script src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
		<script src="https://unpkg.com/ionicons@4.5.10-1/dist/ionicons.js"></script>
		<link href="https://fonts.googleapis.com/css?family=Lato|Open+Sans&display=swap" rel="stylesheet">
		<script src="https://www.google.com/recaptcha/api.js" async defer></script>
		<!--Datatable.js-->
		<link rel="stylesheet" type="text/css" href="plugins/datatable-master/css/datatable.min.css" media="screen">

		<!-- Latest compiled and minified CSS -->
		<link rel="stylesheet" href="https://unpkg.com/multiple-select@1.5.2/dist/multiple-select.min.css">

		<!-- Latest compiled and minified JavaScript -->
		<script src="https://unpkg.com/multiple-select@1.5.2/dist/multiple-select.min.js"></script>
                        
		<!-- JS files -->
		<script type="text/javascript" src="plugins/datatable-master/js/datatable.min.js"></script>
		                        
		<!-- Add the following if you want to use the jQuery wrapper (you still need datatable.min.js): -->
		<script type="text/javascript" src="plugins/datatable-master/js/jquery.min.js"></script>
		<script type="text/javascript" src="plugins/datatable-master/js/datatable.jquery.min.js"></script>
		<title>Admin Panel - Trinity LTMMC</title>