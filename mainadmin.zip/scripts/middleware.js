import { formValidate } from '../assets/script/validate.js';
import { fileValidate } from '../assets/script/validate.js';
import { ajaxInsertFunction } from '../api/ajaxfunction.js';
import { ajaxAddImgFunction } from '../api/ajaxfunction.js';
import { ajaxBlockFunction } from '../api/ajaxfunction.js';
import { ajaxDeleteFunction } from '../api/ajaxfunction.js';
import { ajaxDeleteImgFunction } from '../api/ajaxfunction.js';
import { ajaxUpdateFunction } from '../api/ajaxfunction.js';
import { ajaxLoginFunction } from '../api/ajaxfunction.js';
import { ajaxCsvFunction } from '../api/ajaxfunction.js';

//coupons
window.addCoupon = function addCoupon(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var validate = formValidate(targetId);
	var finput = [];
	targetId.find("label :input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	if(validate == 0){
		ajaxInsertFunction("addCoupon", values, "coupons", reload);
	}
}
window.updateCoupon = function updateCoupon(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var validate = formValidate(targetId);
	var finput = [];
	targetId.find("label :input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	if(validate == 0){
		ajaxUpdateFunction("updateCoupons", values, "coupons", reload);
	}
}
window.blockCoupon = function blockCoupon(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxBlockFunction("blockCoupon", values, "coupons", reload);
}
window.unblockCoupon = function unblockCoupon(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxBlockFunction("unblockCoupon", values, "coupons", reload);
}
window.deleteCoupon = function deleteCoupon(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxDeleteFunction("deleteCoupon", values, "coupons", reload);
}

//Types
window.addSeries = function addSeries(clickid){
	var targetId = $("#"+clickid).parents("form");
	var validate = formValidate(targetId);	
	var finput = {};
	var pushval;
	var pushname;
	targetId.find("label :input:not(li :input, :input[type=button])").each(function(){
		console.log($(this));
		if ($(this).attr("type") == "file") {
			var inputnamehere = $(this).attr("name");
			finput[inputnamehere] = (localStorage.getItem(inputnamehere));
		}else{
			pushval = $(this).val();
			pushname = $(this).attr("name");
			finput[pushname] = pushval;
		}
	});
	var values = JSON.stringify(finput);
	console.log(values);
	if(validate == 0){
		ajaxInsertFunction("addSeries", values);
	}
}
window.updateSlots = function updateSlots(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var validate = formValidate(targetId);
	var finput = {};
	targetId.find("label input").each(function(){
		finput[$(this).attr("name")] = ($(this).val());
	});
	var values = JSON.stringify(finput);
	if(validate == 0){
		ajaxUpdateFunction("updateSlots", values, "slots?ewsid="+finput["ewsid"], reload);
	}
}
window.blockSlot = function blockSlot(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var runid = finput[1];
	finput.pop();
	var values = JSON.stringify(finput);
	ajaxBlockFunction("blockSlot", values, "slots?ewsid="+runid, reload);
}
window.unblockSlot = function unblockSlot(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var runid = finput[1];
	finput.pop();
	var values = JSON.stringify(finput);
	ajaxBlockFunction("unblockSlot", values, "slots?ewsid="+runid, reload);
}
window.deleteSlot = function deleteSlot(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var runid = finput[1];
	finput.pop();
	var values = JSON.stringify(finput);
	ajaxDeleteFunction("deleteSlot", values, "slots?runid="+runid, reload);
}


//Runs
window.addEvent = function addEvent(clickid){
	var targetId = $("#"+clickid).parents("form");
	var validate = formValidate(targetId);	
	var finput = {};
	var pushval;
	var pushname;
	targetId.find("label :input:not(li :input, :input[type=button])").each(function(){
		console.log($(this));
		if ($(this).attr("type") == "file") {
			var inputnamehere = $(this).attr("name");
			finput[inputnamehere] = (localStorage.getItem(inputnamehere));
		}else if($(this).prop("multiple") == true) {
			pushval = $(this).val();
			if (pushval !== null) {
				pushval = pushval.join(",");
			}
			pushname = $(this).attr("name");
			finput[pushname] = pushval;
		}else{
			pushval = $(this).val();
			pushname = $(this).attr("name");
			finput[pushname] = pushval;
		}
	});
	var values = JSON.stringify(finput);
	console.log(values);
	if(validate == 0){
		ajaxInsertFunction("addEvent", values);
	}
}
window.updateEws = function updateEws(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var validate = formValidate(targetId);
	var finput = {};
	targetId.find("label :input:not(li :input)").each(function(){
		finput[$(this).attr("name")] = ($(this).val());	
	});
	var values = JSON.stringify(finput);
	if(validate == 0){
	    ajaxUpdateFunction("updateEws", values, "events-workshops", reload);
	}
}
window.blockEws = function blockEws(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxBlockFunction("blockEws", values, "events-workshops", reload);
}
window.unblockEws = function unblockEws(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxBlockFunction("unblockEws", values, "events-workshops", reload);
}
window.deleteEws = function deleteEws(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxDeleteFunction("deleteEws", values, "events-workshops", reload);
}

//notifications
window.addTags = function addTags(clickid){
	var targetId = $("#"+clickid).parents("form");
	var validate = formValidate(targetId);	
	var finput = {};
	var pushval;
	var pushname;
	targetId.find("label :input:not(li :input)").each(function(){
		pushval = $(this).val();
		pushname = $(this).attr("name");
		finput[pushname] = pushval;
	});
	var values = JSON.stringify(finput);
	console.log(values);
	if(validate == 0){
		ajaxInsertFunction("addTags", values);
	}
}
$(document).on("change","#notifimage",function(){
	var inputnamehere = $(this).attr("name");
	localStorage.removeItem(inputnamehere);
	if (this.files && this.files[0]) {

	    var FR= new FileReader();
	    
	    FR.addEventListener("load", function(e) {
	    	localStorage.setItem(inputnamehere, e.target.result);
	    }); 
	    FR.readAsDataURL( this.files[0] );
	}
});

window.blockNotif = function blockNotif(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxBlockFunction("blockNotif", values, "appcms", reload);
}
window.unblockNotif = function unblockNotif(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxBlockFunction("unblockNotif", values, "appcms", reload);
}

//media-library
window.addGuest = function addGuest(clickid){
	var targetId = $("#"+clickid).parents("form");
	var validate = formValidate(targetId);	
	var finput = {};
	var pushval;
	var pushname;
	targetId.find("label :input:not(li :input, :input[type=button])").each(function(){
		console.log($(this));
		if ($(this).attr("type") == "file") {
			var inputnamehere = $(this).attr("name");
			finput[inputnamehere] = (localStorage.getItem(inputnamehere));
		}else{
			pushval = $(this).val();
			pushname = $(this).attr("name");
			finput[pushname] = pushval;
		}
	});
	var values = JSON.stringify(finput);
	console.log(values);
	if(validate == 0){
		ajaxInsertFunction("addGuest", values);
	}
}

window.deleteImg = function deleteImg(clickid, reload){
	var targetId = $("#"+clickid).parent();
	var finput = [];
	targetId.find("input").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	ajaxDeleteImgFunction("deleteImg", values, "media-library", reload);
}

//logintry
window.loginTry = function loginTry(clickid){
	var targetId = $("#"+clickid).parent();
	var validate = formValidate(targetId);
	var finput = [];
	targetId.find("label :input:not(li :input)").each(function(){
		finput.push($(this).val());
	});
	var values = JSON.stringify(finput);
	if(validate == 0){
	    ajaxLoginFunction("loginTry", values);
	}
}

//Report download
window.csvDownload = function csvDownload(runid){
	ajaxCsvFunction("csvDownload", runid);
}

window.iniDownload = function iniDownload(runid){
	ajaxCsvFunction("iniDownload", runid);
}