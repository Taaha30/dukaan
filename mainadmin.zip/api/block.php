<?php
require '../config.php';
function blockQ($tablename, $valueid, $conn, $msg){
	$query = "UPDATE ".$tablename." SET block = 1, blockedon = '".$valueid[1]."' WHERE uid = '".$valueid[0]."';";
	$query_result = mysqli_query($conn, $query);
	if ($query_result) {
		echo "<span class='success'>".$msg."</span>";
	}else{
		echo "<span class='fail'>Command failed: " . mysqli_error($conn)."<br>Error ref. code: " . mysqli_errno($conn)."</span>";
	}
	mysqli_close($conn);
}
function unblockQ($tablename, $valueid, $conn, $msg){
	$query = "UPDATE ".$tablename." SET block = 0, blockedon = '".$valueid[1]."' WHERE uid = ".$valueid[0].";";
	$query_result = mysqli_query($conn, $query);
	if ($query_result) {
		echo "<span class='success'>".$msg."</span>";
	}else{
		echo "<span class='fail'>Command failed: " . mysqli_error($conn)."<br>Error ref. code: " . mysqli_errno($conn)."</span>";
	}
	mysqli_close($conn);
}

//Coupons
function blockCoupon($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals, $value);
	}
	array_push($fvals, $dandt);
	$table = "coupons";
	$msg = "Coupon blocked successfully";
	blockQ($table, $fvals, $conn, $msg);
}
function unblockCoupon($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals, $value);
	}
	array_push($fvals, $dandt);
	$table = "coupons";
	$msg = "Coupon unblocked successfully";
	unblockQ($table, $fvals, $conn, $msg);
}
if ($_POST["action"] == "blockCoupon") {
	blockCoupon($datetime, $connection);
}
if ($_POST["action"] == "unblockCoupon") {
	unblockCoupon($datetime, $connection);
}

//Run types
function blockSlot($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals, $value);
	}
	array_push($fvals, $dandt);
	$table = "slots";
	$msg = "Slot blocked successfully";
	blockQ($table, $fvals, $conn, $msg);
}
function unblockSlot($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals, $value);
	}
	array_push($fvals, $dandt);
	$table = "slots";
	$msg = "Slot unblocked successfully";
	unblockQ($table, $fvals, $conn, $msg);
}
if ($_POST["action"] == "blockSlot") {
	blockSlot($datetime, $connection);
}
if ($_POST["action"] == "unblockSlot") {
	unblockSlot($datetime, $connection);
}

//Runs
function blockEws($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals, $value);
	}
	array_push($fvals, $dandt);
	$table = "evenws";
	$msg = "Blocked successfully";
	blockQ($table, $fvals, $conn, $msg);
}
if ($_POST["action"] == "blockEws") {
	blockEws($datetime, $connection);
}
function unblockEws($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals, $value);
	}
	array_push($fvals, $dandt);
	$table = "evenws";
	$msg = "Unblocked successfully";
	unblockQ($table, $fvals, $conn, $msg);
}
if ($_POST["action"] == "unblockEws") {
	unblockEws($datetime, $connection);
}

//Notifs
function blockNotif($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals, $value);
	}
	array_push($fvals, $dandt);
	$table = "trinityapp.notifs";
	$msg = "Blocked successfully";
	blocknotifQ($table, $fvals, $conn, $msg);
}
if ($_POST["action"] == "blockNotif") {
	blockNotif($datetime, $connection3);
}
function unblockNotif($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals, $value);
	}
	array_push($fvals, $dandt);
	$table = "trinityapp.notifs";
	$msg = "Unblocked successfully";
	unblocknotifQ($table, $fvals, $conn, $msg);
}
if ($_POST["action"] == "unblockNotif") {
	unblockNotif($datetime, $connection3);
}

function blocknotifQ($tablename, $valueid, $conn, $msg){
	$query = "UPDATE ".$tablename." SET showhide = 1, showhideon = '".$valueid[1]."' WHERE uid = '".$valueid[0]."';";
	$query_result = mysqli_query($conn, $query);
	if ($query_result) {
		echo "<span class='success'>".$msg."</span>";
	}else{
		echo "<span class='fail'>Command failed: " . mysqli_error($conn)."<br>Error ref. code: " . mysqli_errno($conn)."</span>";
	}
	mysqli_close($conn);
}
function unblocknotifQ($tablename, $valueid, $conn, $msg){
	$query = "UPDATE ".$tablename." SET showhide = 0, showhideon = '".$valueid[1]."' WHERE uid = ".$valueid[0].";";
	$query_result = mysqli_query($conn, $query);
	if ($query_result) {
		echo "<span class='success'>".$msg."</span>";
	}else{
		echo "<span class='fail'>Command failed: " . mysqli_error($conn)."<br>Error ref. code: " . mysqli_errno($conn)."</span>";
	}
	mysqli_close($conn);
}
