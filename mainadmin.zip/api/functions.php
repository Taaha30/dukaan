<?php
//dashboard
//Website views
include './api/config.php';

function eventsCall(){
    $fetch = new Connection();

	$query = "SELECT uid, name, date, time, tags, hname, gname, link, series, block from events ORDER BY createdon DESC";

	$fetch->sqlQuery($query);
    $fetch_types = $fetch->fetch();

	$rows = array();
	foreach ($fetch_types as $key => $value) {
		$rows[$key] = $value;		
	}
	return $rows;
}

function seriesCall(){
    $fetch = new Connection();

	$query = "SELECT uid, name, image, about, block, createdon from series ORDER BY createdon DESC";

	$fetch->sqlQuery($query);
    $fetch_types = $fetch->fetch();

	$rows = array();
	foreach ($fetch_types as $key => $value) {
		$rows[$key] = $value;		
	}
	return $rows;
}


function guestsCall(){
    $fetch = new Connection();

	$query = "SELECT uid, name, gtype, image, about, number, instagram, linkedin, twitter, facebook, block, createdon from kliveguest ORDER BY createdon DESC";

	$fetch->sqlQuery($query);
    $fetch_types = $fetch->fetch();

	$rows = array();
	foreach ($fetch_types as $key => $value) {
		$rows[$key] = $value;
	}
	return $rows;
}


function tagsCall(){
    $fetch = new Connection();

	$query = "SELECT uid, tags, block, createdon from tags ORDER BY createdon DESC";

	$fetch->sqlQuery($query);
    $fetch_types = $fetch->fetch();

	$rows = array();
	foreach ($fetch_types as $key => $value) {
		$rows[$key] = $value;
	}
	return $rows;
}

?>