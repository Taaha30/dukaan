<?php
require '../config.php';
function updateQ($tablename, $fields, $condition, $conn, $msg){
	$query = "update ".$tablename." set ";
    foreach($fields as $key => $value) { 
        $fields[$key] = " `$key` = '".mysqli_escape_string($conn, $value)."' ";
    }
    $query .= implode(" , ",array_values($fields))." where ".$condition.";";
	$query_result = mysqli_query($conn, $query);
	if ($query_result) {
		echo "<span class='success'>".$msg."</span>";
	}else{
		echo "<span class='fail'>Command failed: " . mysqli_error($conn)."<br>Error ref. code: " . mysqli_errno($conn)."</span>";
	}
	mysqli_close($conn);
}

//Slots
function updateSlots($dandt, $conn){
	$values = json_decode(stripslashes($_POST['data']));
	$fvals = array();
	foreach ($values as $key => $value) {
		$fvals[$key] = htmlspecialchars(stripslashes(trim($value)));
	}
	array_push($fvals, $dandt);
	extract($fvals);

	$table = "slots";
	$fields = array('name' => $slotname, 'detail' => $slotdetail, 'maxslots' => $slotmax, 'updatedon' => $dandt);
	$msg = "Slot updated successfully";
	updateQ($table, $fields, "uid = '".$slotid."'", $conn, $msg);
}

if ($_POST["action"] == "updateSlots") {
	updateSlots($datetime, $connection);
}

//Coupons
function updateCoupons($dandt, $conn){
	$values = json_decode($_POST['data']);
	$fvals = array();
	foreach ($values as $key => $value) {
		array_push($fvals,  htmlspecialchars(stripslashes(trim($value))));
	}
	array_push($fvals, $dandt);
	$table = "coupons";
	$fields = array('code' => $fvals[0], 'info' => $fvals[1], 'codeval' => $fvals[2], 'type' => $fvals[3], 'maxuse' => $fvals[4], 'expiry' => $fvals[5], 'updatedon' => $dandt);
	$msg = "Coupon updated successfully";
	updateQ($table, $fields, "uid = '".$fvals[6]."'", $conn, $msg);
}

if ($_POST["action"] == "updateCoupons") {
	updateCoupons($datetime, $connection);
}

//EWS
function updateEws($dandt, $conn){
	$values = json_decode($_POST['data']);
	$fvals = array();
	foreach ($values as $key => $value) {
		$fvals[$key] = htmlspecialchars(stripslashes(trim($value)));
	}
	array_push($fvals, $dandt);
	extract($fvals); 

	$table = "evenws";
	$fields = array('type' => $ewstype, 'name' => $ewsname, 'price' => $ewsprice, 'updatedon' => $dandt);
	$msg = $ewstype." updated successfully";
	updateQ($table, $fields, "uid = '".$ewsid."'", $conn, $msg);
}

if ($_POST["action"] == "updateEws") {
	updateEws($datetime, $connection);
}