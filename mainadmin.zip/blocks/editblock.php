<div id="edit-box">
	<div class="tint" onclick="closeEdit()">
	<p class="closebut" style="
    position: absolute;
    font-size: 14px;
    right: 50px;
    color: #fff;
">Close</p>
</div>
	<div id="edit-inbox">
	</div>
</div>