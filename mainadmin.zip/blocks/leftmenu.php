<div id="leftmenu">
	<a href="logout"><div id="logout"><ion-icon name="exit"></ion-icon><p>Logout</p></div></a>
	<div id="logo">
		<img src="http://trinityltmmc.in/images/trinitylogo1.png">
	</div>
	<div class="fullmenu">
		<a href="delegates"><div><ion-icon name="analytics"></ion-icon> <span>Delegates</span></div></a>
		<a href="events-workshops"><div><ion-icon name="barcode"></ion-icon> <span>Events & workshops</span></div></a>
		<a href="tiws-reg"><div><ion-icon name="jet"></ion-icon> <span>TIWS registrations</span></div></a>
		<a href="appcms"><div><ion-icon name="phone-portrait"></ion-icon> <span>App notifications</span></div></a>
		<a href="initialize"><div><ion-icon name="wallet"></ion-icon> <span>Initialized payments</span></div></a>
	</div>
</div>