<?php
function reloadEws($data){
echo "<div class='boxfull-new'>";
			$blocknumb = 0;
				foreach ($data as $image => $value) {
					strtolower($value["type"]) == "event" ? $firstdiv = "<div style='font-size:12px;background:#00bfff;color:#fff;text-align:center;margin:10px;height:50px;line-height:50px;'>".$value['type']."</div>" : $firstdiv = "<div style='font-size:12px;background:#7cfc00;color:#fff;text-align:center;margin:10px;height:50px;line-height:50px;'>".$value['type']."</div>";
					if ($value['block'] == 1) {
						echo "<div class='mute runnames blocknumb'>
							".$firstdiv."
							<div><span class='searchasset'>".$value['name']."</span><br><span class='small'><i class=\"fa fa-inr\" aria-hidden=\"true\"></i>".$value['price']."/-</span></div>
							<div><form><input type='hidden' name='rowid' value='".$value["uid"]."'/>
							<span onclick='window.location.href=\"./slots?ewsid=".$value["uid"]."\"' class='action-buts'><ion-icon name=\"list-box\"></ion-icon> View details</span>
							<span class='action-buts edit-but runs-edit' onclick=\"editDropdown()\" data-key=\"edit-run\" data-value=\"".$value["uid"]."\"><ion-icon name='create'></ion-icon> Edit</span>
							<span class ='action-buts' id='unblockbut".$blocknumb."' onclick='unblockEws(this.id, \"ews-table\")'><ion-icon name='eye'></ion-icon> Unblock</span>
							<div class='delete-but'>
							<div class='delete-in'><ion-icon name='more'></ion-icon></div>
							<div class='delete-menu'>
							<span class ='action-buts' id='deletebut".$blocknumb."' onclick='deleteEws(this.id, \"ews-table\")'><ion-icon name='close-circle'></ion-icon> Delete permanently</span>
							</div>
							</div>
							</form>
							</div>
							</div>";
					}else{
						echo "<div class='runnames blocknumb'>
							".$firstdiv."
							<div><span class='searchasset'>".$value['name']."</span><br><span class='small'><i class=\"fa fa-inr\" aria-hidden=\"true\"></i>".$value['price']."/-</span></div>
							<div><form><input type='hidden' name='rowid' value='".$value["uid"]."'/>
							<span onclick='window.location.href=\"./slots?ewsid=".$value["uid"]."\"' class='action-buts'><ion-icon name=\"list-box\"></ion-icon> View details</span>
							<span class='action-buts edit-but runs-edit' onclick='editDropdown()' data-key='edit-run' data-value='".$value["uid"]."'><ion-icon name='create'></ion-icon> Edit</span>
							<span class ='action-buts' id='blockbut".$blocknumb."' onclick='blockEws(this.id, \"ews-table\")'><ion-icon name='eye-off'></ion-icon> Block</span>
							<div class='delete-but'>
							<div class='delete-in'><ion-icon name='more'></ion-icon></div>
							<div class='delete-menu'>
							<span class ='action-buts' id='deletebut".$blocknumb."' onclick='deleteEws(this.id, \"ews-table\")'><ion-icon name='close-circle'></ion-icon> Delete permanently</span></form>
							</div>
							</div>
							</form>
							</div>
							</div>";
					}
					$blocknumb++;
				}
			echo "</div>";
		}
			?>