<div id="editrun">
	<div class="dash-title">
		<h1>Editing <?php echo $_GET["name"]; ?></h1>
	</div>
<div class="dash-box">
		<form class="validateform">
			<?php
			foreach ($data as $datakey => $datavalue) {
				if ($datavalue["uid"] == $_GET["data"]) {
				echo '<label class="inline-form">
				Type<br>
				<select name="ewstype" required>';
					if($datavalue["type"] == "Event"){
						echo '<option selected>Event</option>';
					}else{
						echo '<option>Event</option>';
					}
					if($datavalue["type"] == "Workshop"){
						echo '<option selected>Workshop</option>';
					}else{
						echo '<option>Workshop</option>';
					}
				echo '</select>
				<span class="validate"></span>
				</label>
				<label class="inline-form">
				name<br>
				<input type="text" name="ewsname" value="'.$datavalue["name"].'" required>
				<span class="validate"></span>
				</label>
				<label class="inline-form">
				Price<br>
				<input type="number" name="ewsprice" value="'.$datavalue["price"].'" required>
				<span class="validate"></span>
				</label><br>
				<label class="inline-form">
				<input type="hidden" name="ewsid" value="'.$datavalue["uid"].'">
				</label><br>';
					}
				}
			?>
			<div id="error"></div>
			<button type="button" value="Submit" id="updateews" onclick="updateEws(this.id, 'ews-table');">Update run</button>
		</form>
	</div>
</div>