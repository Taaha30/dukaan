<form class="validateform bigform">
			<label class="inline-form">
         		Event Name<br>
            	<input type="text" name="name" placeholder="name" required>
				<span class="validate"></span>
			</label>
			<label class="inline-form">
				Event Image<br>
	            <input type="file" class="dropify" name="image" data-height="300" required/>
	           	<span class="validate"></span>
			</label>
			<label class="inline-form">
				Event date <br>
	            <input type="date" name="date" placeholder="name" required>
	           	<span class="validate"></span>
			</label>
			<label class="inline-form">
				Event Time<br>
            	<input type="time" name="time" placeholder="name" required>
           		<span class="validate"></span>
			</label>
			<label class="inline-form">
				Tags<br>
             	<select name="tags" id="tagselect" multiple="multiple" required>
             		<?php
		                foreach ($tags as $key => $value) {
		                	if ($value["block"] == 0) {
		                    	echo "<option value='". $value['uid'] ."'>" .$value['tags'] ."</option>";	     
		                	}
		                }
	                ?>
             	</select>
           		<span class="validate"></span>
			</label>
			<label class="inline-form">
				Event Host<br>
	            <select name = "host" id="hostselect" multiple="multiple" required>
					<?php
		                foreach ($guests as $key => $value) {
		                	if ($value["block"] == 0 && $value["gtype"] == "host") {
			                    echo "<option value='". $value['uid'] ."'>" .$value['name'] ."</option>" ;	     
							}
		                }
	                ?>
				</select>
           		<span class="validate"></span>				
			</label>
			<label class="inline-form">
				Event Guest<br>
            	<select name = "guest" id="guestselect" multiple="multiple" required>
					<?php
		                foreach ($guests as $key => $value) {
		                	if ($value["block"] == 0 && $value["gtype"] == "guest") {
			                    echo "<option value='". $value['uid'] ."'>" .$value['name'] ."</option>" ;	     
							}
		                }
	                ?>
				</select>
           		<span class="validate"></span>
			</label>
			<label class="inline-form">
				Event link<br>
             	<input type="text" name="link" placeholder="name" required>
           		<span class="validate"></span>
			</label>
			<label class="inline-form">
				Event series<br>
            	<select name = "series" required>
					<?php
		                foreach ($series as $key => $value) {
		                	if ($value["block"] == 0) {		                	
		                    	echo "<option value='". $value['uid'] ."'>" .$value['name'] ."</option>" ;
		                    }
		                }
	                ?>
				</select>
           		<span class="validate"></span>
			</label><br>
			<div id="error"></div><br>
			<button type="button" value="Submit" id="addews" onclick="addEvent(this.id, 'ews-table');">Add</button>
		</form>


<script src="./plugins/jqueryupload/dist/js/dropify.min.js"></script>
 <script type="text/javascript">
 $('.dropify').dropify({
 	 messages: {
        'default': 'Drag and drop a file here or click',
        'replace': 'Drag and drop or click to replace',
        'remove':  'Remove',
        'error':   'Ooops, something wrong happend.'
    }
 });

$(function () {
	$('#tagselect,#hostselect,#guestselect').multipleSelect()
})

 $(document).ready(function(){
				$(document).on("change",".dropify",function(){
					var inputnamehere = $(this).attr("name");
					if (this.files && this.files[0]) {

					    var FR= new FileReader();

					    FR.addEventListener("load", function(e) {
					    	localStorage.removeItem(inputnamehere);
					    	localStorage.setItem(inputnamehere, e.target.result);
					console.log(localStorage.getItem(inputnamehere));

					    });
					    FR.readAsDataURL( this.files[0] );
					}
				});
			});

 </script>
  <style type="text/css">
 	.file-icon:before{
	font-family: FontAwesome!important;
	content:"\f0ee"!important;
}
.dropify-infos-inner{padding:0px!important;}
 </style>
