<form class="validateform bigform">
      <label class="inline-form">
            Tag<br>
              <input type="text" name="name" placeholder="name" required>
              <span class="validate"></span>
      </label>
      <br>
      <div id="error"></div><br>
      <button type="button" value="Submit" id="addews" onclick="addTags(this.id, 'tags-table');">Add</button>
    </form>